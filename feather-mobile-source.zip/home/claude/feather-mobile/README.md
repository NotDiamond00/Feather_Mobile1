# Feather Mobile

**A mobile-optimized rebuild of Feather Client loader** — designed for PojavLauncher, Mojo Launcher, PojavLauncher NH, Pojav Glow Worm, and any Android Minecraft launcher that supports Fabric mods.

---

## What's Different from Original Feather Standalone?

| Feature | Original Feather Standalone | Feather Mobile |
|---|---|---|
| Library loading | Downloads from `feathermc.com` at every launch | **Bundled in JAR, no network needed** |
| Network dependency | Required | Optional |
| Startup on bad connection | Hangs / fails | Instant |
| Platform detection | PC only | PojavLauncher, Mojo, NH, etc. |
| `java.awt.Desktop` | Uses it (breaks on Android JVM) | **Removed entirely** |
| Performance profiles | None | LOW_END / BALANCED / HIGH_END (auto-detect) |
| FPS limiting | No | Yes — saves battery |
| Entity culling | No | Yes — Mixin-based distance cull |
| Chunk builder threads | Default (too many for mobile) | Capped to safe mobile range |
| Mobile HUD | No | Yes — FPS, RAM, coordinates |

---

## Requirements

- **Minecraft**: 1.20.4 or newer (tested on 1.21.4)
- **Fabric Loader**: 0.15.11+
- **Java**: 17+ (PojavLauncher ships JRE 17 or 21)
- **Android**: 8.0+ (API 26+) recommended

## Compatible Launchers

| Launcher | Status | Notes |
|---|---|---|
| **PojavLauncher** | ✅ Fully supported | Set JRE 17 or 21 in settings |
| **Mojo Launcher** | ✅ Fully supported | Use Fabric profile |
| **PojavLauncher NH** | ✅ Fully supported | NH fork auto-detected |
| **Pojav Glow Worm** | ✅ Supported | Community fork |
| **Boardwalk (iOS)** | 🧪 Experimental | iOS support untested |
| **PC / Desktop** | ✅ Works | Mobile features disabled automatically |

---

## Installation

### PojavLauncher

1. Open PojavLauncher
2. Go to **Versions** → create or select a **Fabric** profile for MC 1.21.x
3. Set Java version to **JRE 17** or **JRE 21** in the profile settings
4. Download `feather-mobile-1.0.0.jar`
5. Place it in: `Android/data/net.kdt.pojavlauncher/files/mods/`
   - Or use the **Mods** tab in PojavLauncher to import it
6. Launch the game

**Recommended JVM arguments for PojavLauncher** (paste into JVM args field):
```
-Xms512m -Xmx2g -XX:+UseG1GC -XX:MaxGCPauseMillis=20 -XX:G1NewSizePercent=20 -XX:G1ReservePercent=20 -XX:G1HeapRegionSize=32m -XX:G1MixedGCCountTarget=4 -XX:InitiatingHeapOccupancyPercent=15 -Dfabric.debug.disableClassPathIsolation=true
```

Adjust `-Xmx` based on your RAM:
- 2 GB phone → `-Xmx1g`
- 4 GB phone → `-Xmx2g`
- 6 GB phone → `-Xmx3g`
- 8 GB phone → `-Xmx4g`

### Mojo Launcher

1. Open Mojo Launcher
2. Create or select a **Fabric** profile
3. Set Java to **Java 17**
4. Download `feather-mobile-1.0.0.jar`
5. Tap **Mods** → **Add from storage** → select the JAR
6. Launch

### PojavLauncher NH

Same as PojavLauncher above. The mod auto-detects the NH fork and enables NH-specific optimizations.

---

## Configuration

On first launch, a config file is created at:
```
.minecraft/config/feather-mobile.json
```

Default config:
```json
{
  "performanceProfile": "BALANCED",
  "fpsLimit": 60,
  "renderDistanceOverride": -1,
  "showMobileHud": true,
  "chunkBuilderThreads": 2,
  "aggressiveEntityCulling": true,
  "particleMultiplier": 50
}
```

### Performance Profiles

| Profile | RAM target | FPS cap | Render dist | Chunk threads |
|---|---|---|---|---|
| `LOW_END` | <1.5 GB | 30 | 6 | 1 |
| `BALANCED` | 1.5–3 GB | 60 | game default | 2 |
| `HIGH_END` | 3+ GB | unlimited | game default | 3 |

The profile is **auto-detected** from available JVM heap on first launch. You can override it in the JSON config.

### Config Options

| Option | Description |
|---|---|
| `fpsLimit` | Max frames per second. `0` = uncapped |
| `renderDistanceOverride` | Force render distance. `-1` = use game setting |
| `showMobileHud` | Show FPS / RAM / coords overlay |
| `chunkBuilderThreads` | Worker threads for chunk geometry. `1`–`4` |
| `aggressiveEntityCulling` | Skip rendering entities beyond cull distance |
| `particleMultiplier` | Particle density 0–100% |

---

## Mobile HUD

When `showMobileHud: true`, a lightweight overlay is drawn:

```
60 fps              512/2048MB (25%)
                   [POJAV]

      X:1204  Y:64  Z:-892
```

- **Top-left**: Current FPS (turns red below 20fps)
- **Top-right**: RAM usage + active launcher name
- **Bottom-center**: Player coordinates

The HUD hides automatically when the F3 debug screen is open.

---

## System Properties (Advanced)

You can override behavior via JVM `-D` flags in your launcher:

| Property | Values | Effect |
|---|---|---|
| `feather.mobile.disabled` | `true` | Completely disable Feather Mobile |
| `feather.mobile.offline` | `true` | Force offline library mode |
| `feather.mobile.platform` | `POJAV`, `MOJO`, `POJAV_NH`, `DESKTOP` | Override platform detection |
| `feather.mobile.active` | `true` | Force mobile features even on desktop |

Example for PojavLauncher JVM args:
```
-Dfeather.mobile.platform=POJAV -Dfeather.mobile.active=true
```

---

## Bundling Your Own Libraries

To include additional Feather libraries offline:

1. Create `/src/main/resources/libraries/` in the project
2. Place library JARs there
3. Create `index.txt` with one filename per line:
   ```
   # Comments are ignored
   feather-client-core.jar
   feather-renderer.jar
   ```
4. Build the JAR — libraries are extracted to `mods/feather-mobile/libs/` at runtime

---

## Building from Source

```bash
git clone https://github.com/feather-mobile/feather-mobile
cd feather-mobile
./gradlew build
# Output: build/libs/feather-mobile-1.0.0.jar
```

Requires Gradle 8+ and JDK 17+.

---

## Troubleshooting

**Game crashes on startup**
- Check that Fabric Loader 0.15.11+ is installed
- Ensure Java 17 or 21 is selected in your launcher
- Look for `[FeatherMobile]` lines in the crash log

**HUD not visible**
- Set `showMobileHud: true` in `config/feather-mobile.json`
- HUD is hidden while F3 debug screen is open

**Very low FPS despite Feather Mobile**
- Lower `renderDistanceOverride` to `6` or `8`
- Set `performanceProfile: "LOW_END"`
- Reduce `fpsLimit` to `30`
- Use Sodium + Lithium + Starlight alongside Feather Mobile for best results

**Library not found error**
- This is non-fatal; Feather Mobile skips library loading gracefully
- The mod still works for HUD and optimization features

---

## Recommended Companion Mods

For the best performance on mobile, use Feather Mobile alongside:

| Mod | Purpose |
|---|---|
| **Sodium** | GPU rendering optimization |
| **Lithium** | Server/tick loop optimization |
| **Starlight** | Lighting engine rewrite |
| **FerriteCore** | Memory usage reduction |
| **EntityCulling** | Additional entity visibility culling |
| **Krypton** | Network stack optimization |

---

## License

MIT License. Original Feather Standalone was CC0-1.0 (Digital Ingot Inc.).
