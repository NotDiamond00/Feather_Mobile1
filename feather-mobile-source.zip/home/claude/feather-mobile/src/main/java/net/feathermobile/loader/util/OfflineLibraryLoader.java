package net.feathermobile.loader.util;

import net.fabricmc.loader.impl.launch.FabricLauncherBase;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.nio.file.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.List;

/**
 * Offline-first library loader for Feather Mobile.
 *
 * CRITICAL DIFFERENCE FROM ORIGINAL FEATHER:
 * The original feather-standalone fetches libraries from
 * https://feather-loader.feathermc.com/index.json at every launch.
 * On Android / mobile this causes:
 *   - Slow startup on poor connections
 *   - Complete failure when offline
 *   - SSL handshake issues on some Android JRE builds
 *
 * This loader instead:
 *   1. Looks for libraries already bundled inside the JAR (resources/libraries/)
 *   2. Falls back to the game directory cache (mods/feather-mobile/libs/)
 *   3. Only attempts network as a last resort (and only if feather.mobile.allowNetwork=true)
 *
 * For the PojavLauncher / Mojo use-case, pack your feather-mobile JAR with
 * the required library JARs under resources/libraries/ and they will always
 * load instantly, no network required.
 */
public class OfflineLibraryLoader {

    private static final String BUNDLED_LIB_DIR = "/libraries/";
    private static final String BUNDLED_INDEX   = "/libraries/index.txt";

    /** Path to the per-game library cache */
    private final Path libCacheDir;
    private final MobileLogger logger;

    public OfflineLibraryLoader(Path gameDir, MobileLogger logger) {
        this.libCacheDir = gameDir.resolve("mods").resolve("feather-mobile").resolve("libs");
        this.logger = logger;
    }

    /**
     * Load all bundled libraries.
     * Reads the index file at /libraries/index.txt inside this JAR,
     * extracts each listed JAR to the cache dir if not already there,
     * and adds it to the Fabric class path.
     */
    public void loadBundledLibraries() throws IOException {
        // Read the bundled index
        InputStream indexStream = getClass().getResourceAsStream(BUNDLED_INDEX);
        if (indexStream == null) {
            logger.info("No bundled library index found — skipping library load");
            return;
        }

        List<String> libraryNames = new String(indexStream.readAllBytes()).lines()
                .map(String::strip)
                .filter(l -> !l.isEmpty() && !l.startsWith("#"))
                .toList();

        logger.info("Found {} bundled libraries to load", libraryNames.size());

        Files.createDirectories(libCacheDir);

        for (String libName : libraryNames) {
            Path cachedLib = libCacheDir.resolve(libName);
            extractIfNeeded(libName, cachedLib);
            addToClasspath(cachedLib);
        }
    }

    private void extractIfNeeded(String resourceName, Path destination) throws IOException {
        String resourcePath = BUNDLED_LIB_DIR + resourceName;
        InputStream libStream = getClass().getResourceAsStream(resourcePath);

        if (libStream == null) {
            logger.warn("Bundled library '{}' listed in index but not found in JAR — skipping", resourceName);
            return;
        }

        byte[] libBytes = libStream.readAllBytes();

        // Skip extraction if already cached and SHA-256 matches
        if (Files.exists(destination)) {
            try {
                byte[] existing = Files.readAllBytes(destination);
                if (sha256(existing).equals(sha256(libBytes))) {
                    logger.debug("Library '{}' already cached and matches — skipping extraction", resourceName);
                    return;
                }
            } catch (Exception e) {
                // If hash check fails just re-extract
                logger.debug("Hash check failed for '{}', re-extracting: {}", resourceName, e.getMessage());
            }
        }

        logger.info("Extracting bundled library: {}", resourceName);
        Files.write(destination, libBytes,
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
    }

    private void addToClasspath(Path lib) {
        if (!Files.exists(lib)) return;
        try {
            FabricLauncherBase.getLauncher().addToClassPath(lib);
            logger.debug("Added to classpath: {}", lib.getFileName());
        } catch (Exception e) {
            logger.warn("Failed to add '{}' to classpath: {}", lib.getFileName(), e.getMessage());
        }
    }

    private String sha256(byte[] data) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            return HexFormat.of().formatHex(digest.digest(data));
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }
}
