package net.feathermobile;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.feathermobile.client.hud.MobileHud;
import net.feathermobile.client.optimization.ChunkBuilderOptimizer;
import net.feathermobile.client.optimization.EntityCullingOptimizer;
import net.feathermobile.client.optimization.FpsLimiter;
import net.feathermobile.loader.config.FeatherMobileConfig;
import net.feathermobile.loader.platform.MobilePlatformDetector;
import net.feathermobile.loader.platform.PlatformType;
import net.feathermobile.loader.util.MobileLogger;
import net.minecraft.client.MinecraftClient;

import java.nio.file.Path;

/**
 * Feather Mobile — Client Entrypoint
 *
 * Registers:
 *   - Mobile HUD (FPS, RAM, coords)
 *   - FPS limiter (battery-aware)
 *   - Entity culling optimizer
 *   - Chunk builder thread count optimizer
 *   - Mobile-specific keybind overrides (controller/touch friendly)
 */
@Environment(EnvType.CLIENT)
public class FeatherMobileClient implements ClientModInitializer {

    private static final MobileLogger LOGGER = new MobileLogger("Client");

    private static FeatherMobileConfig config;
    private static PlatformType platform;

    @Override
    public void onInitializeClient() {
        // Only apply mobile-specific features on mobile
        platform = MobilePlatformDetector.detect();
        boolean isMobile = platform.isMobile() || Boolean.getBoolean("feather.mobile.active");

        LOGGER.info("Feather Mobile client init — platform: {}, mobile features: {}", platform, isMobile);

        // Load config (use already-detected game dir from Fabric)
        Path gameDir = net.fabricmc.loader.api.FabricLoader.getInstance().getGameDir();
        config = FeatherMobileConfig.loadOrCreate(gameDir);

        // Register mobile HUD
        if (config.showMobileHud) {
            MobileHud hud = new MobileHud(config, platform);
            HudRenderCallback.EVENT.register(hud::render);
            LOGGER.info("Mobile HUD registered");
        }

        // FPS limiter
        if (config.fpsLimit > 0) {
            FpsLimiter fpsLimiter = new FpsLimiter(config.fpsLimit);
            ClientTickEvents.END_CLIENT_TICK.register(fpsLimiter::onEndTick);
            LOGGER.info("FPS limiter registered: {}fps cap", config.fpsLimit);
        }

        // Entity culling
        if (isMobile && config.aggressiveEntityCulling) {
            EntityCullingOptimizer.install();
            LOGGER.info("Aggressive entity culling installed");
        }

        // Chunk builder thread optimization
        if (isMobile) {
            ChunkBuilderOptimizer.apply(config.chunkBuilderThreads);
            LOGGER.info("Chunk builder threads set to {}", config.chunkBuilderThreads);
        }

        // Render distance override
        if (config.renderDistanceOverride > 0) {
            ClientTickEvents.START_CLIENT_TICK.register(client -> {
                if (client.options != null) {
                    int current = client.options.getViewDistance().getValue();
                    if (current > config.renderDistanceOverride) {
                        client.options.getViewDistance().setValue(config.renderDistanceOverride);
                    }
                }
            });
            LOGGER.info("Render distance capped at {}", config.renderDistanceOverride);
        }

        LOGGER.info("Feather Mobile client init complete");
    }

    public static FeatherMobileConfig getConfig() {
        return config;
    }

    public static PlatformType getPlatform() {
        return platform;
    }
}
