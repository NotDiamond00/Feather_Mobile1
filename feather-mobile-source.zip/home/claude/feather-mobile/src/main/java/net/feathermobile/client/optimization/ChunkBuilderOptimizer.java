package net.feathermobile.client.optimization;

import net.feathermobile.loader.util.MobileLogger;

/**
 * Chunk builder thread count optimizer for mobile.
 *
 * Minecraft 1.20+ uses multiple threads to build chunk geometry.
 * On desktop this defaults to (CPU cores / 2). On mobile, using
 * too many threads causes thermal throttling and stutters.
 *
 * Recommended values:
 *   LOW_END  : 1 thread  (Snapdragon 660 / Helio G80 era)
 *   BALANCED : 2 threads (Snapdragon 720G / Dimensity 900)
 *   HIGH_END : 3 threads (Snapdragon 8 Gen 1 / Dimensity 9000)
 *
 * Full control requires a Mixin on ChunkBuilder's thread count.
 * This class sets the system property that the Mixin reads.
 */
public class ChunkBuilderOptimizer {

    private static final MobileLogger LOGGER = new MobileLogger("ChunkBuilder");

    public static void apply(int threadCount) {
        int capped = Math.max(1, Math.min(threadCount, 4));
        System.setProperty("feather.mobile.chunkBuilderThreads", String.valueOf(capped));
        LOGGER.info("Chunk builder thread count capped at {}", capped);
    }

    public static int getThreadCount() {
        try {
            return Integer.parseInt(
                System.getProperty("feather.mobile.chunkBuilderThreads", "2")
            );
        } catch (NumberFormatException e) {
            return 2;
        }
    }
}
