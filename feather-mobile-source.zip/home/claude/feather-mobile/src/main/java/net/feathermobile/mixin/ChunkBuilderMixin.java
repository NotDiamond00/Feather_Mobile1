package net.feathermobile.mixin;

import net.feathermobile.client.optimization.ChunkBuilderOptimizer;
import net.minecraft.client.render.chunk.ChunkBuilder;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

/**
 * Limits the number of chunk builder threads on mobile.
 *
 * ChunkBuilder's constructor calculates thread count from available processors.
 * On mobile this can spin up 4-8 threads, causing thermal throttling.
 * This mixin caps the thread count to the value set by ChunkBuilderOptimizer.
 */
@Mixin(ChunkBuilder.class)
public class ChunkBuilderMixin {

    /**
     * Intercepts the thread count passed to the worker pool in ChunkBuilder's <init>.
     * Caps it to the mobile-configured max.
     */
    @ModifyArg(
        method = "<init>",
        at = @At(
            value = "INVOKE",
            target = "Ljava/util/concurrent/Executors;newFixedThreadPool(ILjava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ExecutorService;"
        ),
        index = 0
    )
    private int featherMobile_limitChunkThreads(int original) {
        String prop = System.getProperty("feather.mobile.chunkBuilderThreads");
        if (prop == null) return original;

        int mobileMax = ChunkBuilderOptimizer.getThreadCount();
        return Math.min(original, mobileMax);
    }
}
