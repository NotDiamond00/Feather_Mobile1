package net.feathermobile.mixin;

import net.feathermobile.client.optimization.EntityCullingOptimizer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Injects into EntityRenderDispatcher to skip rendering entities
 * that are outside the mobile-adjusted cull distance.
 *
 * Only active when feather.mobile.entityCulling=true (set by
 * EntityCullingOptimizer.install()).
 */
@Mixin(EntityRenderDispatcher.class)
public class EntityRenderDispatcherMixin {

    @Inject(
        method = "render",
        at = @At("HEAD"),
        cancellable = true
    )
    private <E extends Entity> void featherMobile_cullDistantEntities(
            E entity,
            double x, double y, double z,
            float yaw,
            net.minecraft.client.util.math.MatrixStack matrices,
            net.minecraft.client.render.VertexConsumerProvider vertexConsumers,
            int light,
            Camera camera,
            CallbackInfo ci
    ) {
        if (!EntityCullingOptimizer.isInstalled()) return;

        // Skip culling for the local player
        if (entity == net.minecraft.client.MinecraftClient.getInstance().player) return;

        if (!EntityCullingOptimizer.isInFrustum(x, y, z, camera)) {
            ci.cancel();
        }
    }
}
