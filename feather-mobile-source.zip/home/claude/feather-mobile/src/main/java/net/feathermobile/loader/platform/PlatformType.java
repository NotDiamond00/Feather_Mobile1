package net.feathermobile.loader.platform;

public enum PlatformType {
    /** PojavLauncher (main branch) */
    POJAV(true),
    /** PojavLauncher NH fork */
    POJAV_NH(true),
    /** PojavLauncher Glow Worm community fork */
    POJAV_GLOWWORM(true),
    /** Mojo Launcher */
    MOJO(true),
    /** Boardwalk (iOS, experimental) */
    BOARDWALK_IOS(true),
    /** Android device, unknown launcher */
    GENERIC_ANDROID(true),
    /** Standard desktop JVM */
    DESKTOP(false);

    private final boolean android;

    PlatformType(boolean android) {
        this.android = android;
    }

    public boolean isAndroid() {
        return android;
    }

    public boolean isMobile() {
        return android; // extend for iOS when stable
    }
}
