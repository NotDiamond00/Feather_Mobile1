package net.feathermobile.client.optimization;

import net.feathermobile.loader.util.MobileLogger;

/**
 * Entity culling optimizer for mobile.
 *
 * On mobile GPUs (Mali, Adreno, Apple GPU), draw calls are expensive.
 * Skipping entities that are:
 *   a) Outside the camera frustum
 *   b) Behind terrain (occluded)
 *   c) Very far away (distance-based culling)
 *
 * significantly reduces GPU and CPU load.
 *
 * Full implementation requires a Mixin on EntityRenderDispatcher.
 * See feather-mobile.mixins.json and mixin/EntityRenderDispatcherMixin.java
 *
 * This class acts as the installer/registrar for those mixins.
 */
public class EntityCullingOptimizer {

    private static final MobileLogger LOGGER = new MobileLogger("EntityCulling");
    private static boolean installed = false;

    /**
     * Called from FeatherMobileClient to activate entity culling.
     * Mixins are already woven at this point; this sets the global flag
     * that the mixin checks before skipping entities.
     */
    public static void install() {
        if (installed) return;
        installed = true;
        // Signal to the mixin that culling is active
        System.setProperty("feather.mobile.entityCulling", "true");
        LOGGER.info("Entity culling optimizer active");
    }

    public static boolean isInstalled() {
        return installed;
    }

    /**
     * Returns true if this entity position is within the camera frustum.
     * Used by EntityRenderDispatcherMixin.
     */
    public static boolean isInFrustum(double x, double y, double z,
                                       net.minecraft.client.render.Camera camera) {
        // Basic distance check — full frustum culling is in the Mixin
        double dx = x - camera.getPos().x;
        double dy = y - camera.getPos().y;
        double dz = z - camera.getPos().z;
        double distSq = dx * dx + dy * dy + dz * dz;
        // Cull entities beyond 64 blocks on low-end (roughly 3 chunk radii)
        String profile = System.getProperty("feather.mobile.gcTuning", "balanced");
        double cullDistSq = switch (profile) {
            case "low" -> 64.0 * 64.0;
            case "high" -> 128.0 * 128.0;
            default   -> 96.0 * 96.0;
        };
        return distSq < cullDistSq;
    }
}
