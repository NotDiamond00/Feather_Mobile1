package net.feathermobile.client.optimization;

import net.minecraft.client.MinecraftClient;

/**
 * Software FPS limiter for mobile devices.
 *
 * Minecraft's built-in max FPS option only goes as low as 10fps for
 * "background" mode, not during active gameplay. This enforcer ensures
 * framerate stays at or below the configured cap to:
 *   - Reduce heat generation on thin phones
 *   - Extend battery life (GPU is typically the biggest power consumer)
 *   - Keep the device cool for longer play sessions
 *
 * Works by tracking frame timing and sleeping the render thread if
 * the current frame finished too quickly.
 *
 * Note: This is called from the CLIENT TICK event (20 Hz), not the render
 * loop, so it adjusts MC's own fpsLimit option rather than sleeping — which
 * is the cleanest approach without a mixin.
 */
public class FpsLimiter {

    private final int targetFps;

    public FpsLimiter(int targetFps) {
        this.targetFps = Math.max(1, targetFps);
    }

    /**
     * Called every client tick. Adjusts Minecraft's own max FPS option
     * to match our target, which lets Minecraft's own sleep logic handle
     * the actual timing correctly.
     */
    public void onEndTick(MinecraftClient client) {
        if (client.options == null) return;

        // Read current MC fps limit
        int current = client.options.getMaxFps().getValue();
        if (current != targetFps) {
            client.options.getMaxFps().setValue(targetFps);
        }
    }
}
