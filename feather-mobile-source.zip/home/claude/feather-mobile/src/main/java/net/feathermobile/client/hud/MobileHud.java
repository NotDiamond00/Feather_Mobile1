package net.feathermobile.client.hud;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.feathermobile.loader.config.FeatherMobileConfig;
import net.feathermobile.loader.platform.PlatformType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;

/**
 * Feather Mobile HUD
 *
 * Displays a mobile-friendly overlay:
 *   Top-left:  FPS counter
 *   Top-right: RAM usage (MB used / MB max)
 *   Bottom:    Player coordinates (X, Y, Z) — touch-friendly large font
 *
 * Designed to be readable at arm's length on a phone screen.
 * Uses Minecraft's built-in font renderer — no external dependencies.
 */
public class MobileHud {

    private static final int HUD_COLOR     = 0xFFFFFFFF; // white
    private static final int SHADOW_COLOR  = 0xAA000000; // semi-transparent black bg
    private static final int WARNING_COLOR = 0xFFFF5555; // red for low RAM/FPS
    private static final int OK_COLOR      = 0xFF55FF55; // green for good

    private static final int PADDING    = 4;
    private static final int LINE_H     = 10;
    private static final int SCALE      = 1;

    private final FeatherMobileConfig config;
    private final PlatformType platform;

    private long lastRamCheck = 0;
    private String cachedRamStr = "";
    private int fpsWarningFrames = 0;

    public MobileHud(FeatherMobileConfig config, PlatformType platform) {
        this.config = config;
        this.platform = platform;
    }

    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.options == null) return;

        // Don't render over debug menu (F3)
        if (mc.getDebugHud().shouldShowDebugHud()) return;

        int screenW = mc.getWindow().getScaledWidth();

        // --- FPS Counter (top-left) ---
        int fps = mc.getCurrentFps();
        String fpsStr = fps + " fps";
        int fpsColor = fps < 20 ? WARNING_COLOR : fps < 40 ? 0xFFFFAA00 : OK_COLOR;
        renderTextWithBg(context, fpsStr, PADDING, PADDING, fpsColor);

        // --- RAM (top-right) ---
        long now = System.currentTimeMillis();
        if (now - lastRamCheck > 2000) { // update every 2s
            Runtime rt = Runtime.getRuntime();
            long usedMb  = (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024);
            long maxMb   = rt.maxMemory() / (1024 * 1024);
            int  pct     = (int)(usedMb * 100 / maxMb);
            cachedRamStr = usedMb + "/" + maxMb + "MB (" + pct + "%)";
            lastRamCheck = now;
        }
        int ramColor = cachedRamStr.contains("(") && parseRamPct(cachedRamStr) > 85
                       ? WARNING_COLOR : HUD_COLOR;
        int ramX = screenW - mc.textRenderer.getWidth(cachedRamStr) - PADDING;
        renderTextWithBg(context, cachedRamStr, ramX, PADDING, ramColor);

        // --- Platform label (top-right, below RAM) ---
        if (platform.isMobile()) {
            String platformStr = "[" + platform.name() + "]";
            int px = screenW - mc.textRenderer.getWidth(platformStr) - PADDING;
            renderTextWithBg(context, platformStr, px, PADDING + LINE_H + 1, 0xFF88AAFF);
        }

        // --- Player coords (bottom center) ---
        if (mc.player != null) {
            BlockPos pos = mc.player.getBlockPos();
            String coordStr = String.format("X:%d  Y:%d  Z:%d", pos.getX(), pos.getY(), pos.getZ());
            int cx = (screenW - mc.textRenderer.getWidth(coordStr)) / 2;
            int screenH = mc.getWindow().getScaledHeight();
            renderTextWithBg(context, coordStr, cx, screenH - LINE_H - PADDING - 2, HUD_COLOR);
        }
    }

    private void renderTextWithBg(DrawContext context, String text, int x, int y, int color) {
        MinecraftClient mc = MinecraftClient.getInstance();
        int w = mc.textRenderer.getWidth(text);
        // Draw a subtle dark background for readability on any terrain
        context.fill(x - 1, y - 1, x + w + 1, y + LINE_H, SHADOW_COLOR);
        context.drawText(mc.textRenderer, text, x, y, color, false);
    }

    private int parseRamPct(String ramStr) {
        try {
            int start = ramStr.indexOf('(') + 1;
            int end = ramStr.indexOf('%');
            if (start > 0 && end > start) {
                return Integer.parseInt(ramStr.substring(start, end).trim());
            }
        } catch (Exception ignored) {}
        return 0;
    }
}
