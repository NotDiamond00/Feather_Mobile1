package net.feathermobile.loader.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.feathermobile.loader.util.MobileLogger;

import java.io.IOException;
import java.nio.file.*;

/**
 * Feather Mobile configuration.
 *
 * Stored at: <gameDir>/config/feather-mobile.json
 *
 * Performance Profiles
 * --------------------
 * LOW_END   — Snapdragon 660, Helio G80, 2-3 GB RAM
 *             Render distance ≤ 6, entity culling aggressive, FPS cap 30
 * BALANCED  — Snapdragon 720G / 778G, Dimensity 900, 4 GB RAM
 *             Render distance ≤ 10, moderate culling, FPS cap 60
 * HIGH_END  — Snapdragon 8 Gen 1+, Dimensity 9000, 8+ GB RAM
 *             Render distance ≤ 16, minimal culling, FPS cap 90/120
 */
public class FeatherMobileConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final MobileLogger LOGGER = new MobileLogger("Config");

    // --- Config fields (all JSON-serializable) ---

    /** Device performance tier */
    public PerformanceProfile performanceProfile = PerformanceProfile.BALANCED;

    /** Cap framerate to save battery. 0 = uncapped */
    public int fpsLimit = 60;

    /** Render distance override. -1 = don't override (use game setting) */
    public int renderDistanceOverride = -1;

    /** Show Feather Mobile HUD overlay (FPS, memory) */
    public boolean showMobileHud = true;

    /** Reduce chunk update threads on mobile to avoid stutters */
    public int chunkBuilderThreads = 1;

    /**
     * Aggressive entity culling: skip rendering entities outside camera cone.
     * Greatly helps performance on mobile GPU.
     */
    public boolean aggressiveEntityCulling = true;

    /** Reduce particle count on mobile */
    public int particleMultiplier = 50; // percent; 100 = full, 50 = half

    // --- Factory ---

    public static FeatherMobileConfig loadOrCreate(Path gameDir) {
        Path configPath = gameDir.resolve("config").resolve("feather-mobile.json");

        if (Files.exists(configPath)) {
            try {
                String json = Files.readString(configPath);
                FeatherMobileConfig config = GSON.fromJson(json, FeatherMobileConfig.class);
                LOGGER.info("Config loaded from {}", configPath);
                return config;
            } catch (Exception e) {
                LOGGER.warn("Failed to parse config, using defaults: {}", e.getMessage());
            }
        }

        // Create default config
        FeatherMobileConfig config = new FeatherMobileConfig();
        config.autoDetectProfile();

        try {
            Files.createDirectories(configPath.getParent());
            Files.writeString(configPath, GSON.toJson(config), StandardOpenOption.CREATE_NEW);
            LOGGER.info("Default config written to {}", configPath);
        } catch (IOException e) {
            LOGGER.warn("Could not write config file: {}", e.getMessage());
        }

        return config;
    }

    /** Auto-detect a reasonable profile based on available JVM memory */
    private void autoDetectProfile() {
        long maxRam = Runtime.getRuntime().maxMemory();
        long maxRamMB = maxRam / (1024 * 1024);

        if (maxRamMB < 1500) {
            performanceProfile = PerformanceProfile.LOW_END;
            fpsLimit = 30;
            renderDistanceOverride = 6;
            chunkBuilderThreads = 1;
            particleMultiplier = 25;
        } else if (maxRamMB < 3000) {
            performanceProfile = PerformanceProfile.BALANCED;
            fpsLimit = 60;
            renderDistanceOverride = -1;
            chunkBuilderThreads = 2;
            particleMultiplier = 50;
        } else {
            performanceProfile = PerformanceProfile.HIGH_END;
            fpsLimit = 0;
            renderDistanceOverride = -1;
            chunkBuilderThreads = 3;
            particleMultiplier = 100;
        }

        LOGGER.info("Auto-detected profile {} (max RAM: {} MB)", performanceProfile, maxRamMB);
    }

    public PerformanceProfile getPerformanceProfile() {
        return performanceProfile;
    }

    public enum PerformanceProfile {
        LOW_END,
        BALANCED,
        HIGH_END
    }
}
