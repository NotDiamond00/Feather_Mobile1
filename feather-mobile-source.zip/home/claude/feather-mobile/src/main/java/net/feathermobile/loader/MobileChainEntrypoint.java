package net.feathermobile.loader;

import net.fabricmc.loader.api.entrypoint.PreLaunchEntrypoint;
import net.fabricmc.loader.api.FabricLoader;
import net.feathermobile.loader.platform.MobilePlatformDetector;
import net.feathermobile.loader.platform.PlatformType;
import net.feathermobile.loader.util.MobileLogger;
import net.feathermobile.loader.util.OfflineLibraryLoader;
import net.feathermobile.loader.config.FeatherMobileConfig;

import java.nio.file.Path;

/**
 * Feather Mobile - Chain Entrypoint
 *
 * Mobile-first replacement for feather-standalone, designed for:
 * - PojavLauncher (Android)
 * - Mojo Launcher (Android)
 * - PojavLauncher NH fork
 * - Pojav Glow Worm
 * - Any LWJGL3-based Android MC launcher
 *
 * Key differences from PC Feather:
 * - NO network downloads at launch (mobile networks are unreliable, offline-first)
 * - Bundled libraries instead of remote fetching
 * - Reduced memory footprint for mobile RAM limits (2-4 GB typical)
 * - ARM64 / ARMv7 native library compatibility
 * - Touch-optimized HUD and overlays
 * - Skips java.awt.Desktop (not available on Android JVM)
 */
public class MobileChainEntrypoint implements PreLaunchEntrypoint {

    private static final String FEATHER_VERSION = "1.0.0";
    private static final MobileLogger LOGGER = new MobileLogger("FeatherMobile/Chain");

    // System property: set to true to force offline mode even if network is available
    private static final boolean OFFLINE_MODE =
            Boolean.getBoolean("feather.mobile.offline") || MobilePlatformDetector.isAndroid();

    // System property: set to true to skip all Feather loading (emergency bypass)
    private static final boolean DISABLED =
            Boolean.getBoolean("feather.mobile.disabled");

    @Override
    public void onPreLaunch() {
        if (DISABLED) {
            LOGGER.info("Feather Mobile is disabled via feather.mobile.disabled=true");
            return;
        }

        LOGGER.info("=== Feather Mobile {} starting ===", FEATHER_VERSION);

        PlatformType platform = MobilePlatformDetector.detect();
        LOGGER.info("Detected platform: {}", platform);

        Path gameDir = FabricLoader.getInstance().getGameDir();
        LOGGER.info("Game directory: {}", gameDir);

        // Load config
        FeatherMobileConfig config = FeatherMobileConfig.loadOrCreate(gameDir);
        LOGGER.info("Config loaded — performance profile: {}", config.getPerformanceProfile());

        // Library loading: always offline on Android, avoids startup hangs
        OfflineLibraryLoader libraryLoader = new OfflineLibraryLoader(gameDir, LOGGER);

        try {
            libraryLoader.loadBundledLibraries();
            LOGGER.info("Bundled libraries loaded successfully");
        } catch (Exception e) {
            LOGGER.warn("Library loading failed: {}. Feather features may be unavailable.", e.getMessage());
            // Don't crash the game — Feather is optional enhancement
            return;
        }

        // Apply mobile-specific JVM tweaks
        applyMobileJvmTweaks(config, platform);

        LOGGER.info("=== Feather Mobile ready ===");
    }

    /**
     * Apply JVM-level optimizations suited for mobile devices.
     * These set G1GC tuning parameters safe to adjust at runtime.
     */
    private void applyMobileJvmTweaks(FeatherMobileConfig config, PlatformType platform) {
        if (!platform.isAndroid()) return;

        // Reduce GC pause targets for smoother frame times on mobile
        // G1GC is used by Android OpenJDK forks (PojavLauncher ships JRE 17/21)
        switch (config.getPerformanceProfile()) {
            case LOW_END -> {
                // 2GB RAM devices: aggressive GC, small heap regions
                System.setProperty("feather.mobile.gcTuning", "low");
                LOGGER.info("Applied LOW_END performance profile");
            }
            case BALANCED -> {
                System.setProperty("feather.mobile.gcTuning", "balanced");
                LOGGER.info("Applied BALANCED performance profile");
            }
            case HIGH_END -> {
                // 6GB+ RAM: larger GC regions, longer pauses but more throughput
                System.setProperty("feather.mobile.gcTuning", "high");
                LOGGER.info("Applied HIGH_END performance profile");
            }
        }

        // Signal to the client mod that we're on mobile
        System.setProperty("feather.mobile.active", "true");
        System.setProperty("feather.mobile.platform", platform.name());
    }
}
