package net.feathermobile.loader.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Thin logger wrapper that formats messages safely on Android JVMs.
 * Uses SLF4J (available via Fabric) instead of java.util.logging
 * which may misbehave on some Android OpenJDK builds.
 */
public class MobileLogger {

    private final Logger logger;

    public MobileLogger(String name) {
        this.logger = LoggerFactory.getLogger("[FeatherMobile] " + name);
    }

    public void info(String msg, Object... args) {
        logger.info(format(msg, args));
    }

    public void debug(String msg, Object... args) {
        logger.debug(format(msg, args));
    }

    public void warn(String msg, Object... args) {
        logger.warn(format(msg, args));
    }

    public void error(String msg, Object... args) {
        logger.error(format(msg, args));
    }

    public void error(String msg, Throwable t) {
        logger.error(msg, t);
    }

    /** Replace {} placeholders with args (SLF4J-style) */
    private String format(String template, Object... args) {
        if (args == null || args.length == 0) return template;
        StringBuilder sb = new StringBuilder();
        int argIdx = 0;
        int i = 0;
        while (i < template.length()) {
            if (i < template.length() - 1
                    && template.charAt(i) == '{'
                    && template.charAt(i + 1) == '}') {
                sb.append(argIdx < args.length ? args[argIdx++] : "{}");
                i += 2;
            } else {
                sb.append(template.charAt(i++));
            }
        }
        return sb.toString();
    }
}
