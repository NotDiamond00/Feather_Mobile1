package net.feathermobile.loader.platform;

/**
 * Detects the current mobile launcher platform at runtime.
 *
 * PojavLauncher, Mojo, and other Android launchers expose themselves
 * through system properties and/or the os.name JVM property.
 *
 * Detection priority:
 *   1. Explicit system property  feather.mobile.platform=POJAV|MOJO|POJAV_NH|CUSTOM
 *   2. Known system properties set by each launcher
 *   3. os.name heuristic (Android JVM reports "Linux" but with android markers)
 *   4. Fallback: DESKTOP
 */
public class MobilePlatformDetector {

    private MobilePlatformDetector() {}

    public static boolean isAndroid() {
        // Android JVM always has this property
        String javaVmVendor = System.getProperty("java.vm.vendor", "");
        String javaVmName   = System.getProperty("java.vm.name", "");
        String osName       = System.getProperty("os.name", "");
        String androidData  = System.getProperty("ANDROID_DATA", "");
        String pojav        = System.getProperty("pojav.environ", "");
        String mojo         = System.getProperty("mojonative.environ", "");

        return !androidData.isEmpty()
            || !pojav.isEmpty()
            || !mojo.isEmpty()
            || javaVmVendor.toLowerCase().contains("android")
            || javaVmName.toLowerCase().contains("android")
            || osName.equalsIgnoreCase("android");
    }

    public static PlatformType detect() {
        // 1. Explicit override
        String explicit = System.getProperty("feather.mobile.platform", "").toUpperCase();
        if (!explicit.isEmpty()) {
            try {
                return PlatformType.valueOf(explicit);
            } catch (IllegalArgumentException ignored) {}
        }

        // 2. Launcher-specific properties
        // PojavLauncher sets pojav.environ
        if (System.getProperty("pojav.environ") != null) {
            // PojavLauncher NH fork additionally sets pojav_nh or has different JRE paths
            String jreHome = System.getProperty("java.home", "");
            if (jreHome.contains("pojav_nh") || System.getProperty("pojav.nh") != null) {
                return PlatformType.POJAV_NH;
            }
            return PlatformType.POJAV;
        }

        // Mojo Launcher
        if (System.getProperty("mojonative.environ") != null
                || System.getProperty("mojo.launcher") != null) {
            return PlatformType.MOJO;
        }

        // Pojav Glow Worm (community fork)
        if (System.getProperty("glowworm.environ") != null) {
            return PlatformType.POJAV_GLOWWORM;
        }

        // Boardwalk / iOS (rare, experimental)
        String osArch = System.getProperty("os.arch", "");
        if (System.getProperty("boardwalk.environ") != null
                || osArch.contains("arm64") && System.getProperty("jna.boot.library.path", "").contains("boardwalk")) {
            return PlatformType.BOARDWALK_IOS;
        }

        // Generic Android (unknown launcher but definitely Android)
        if (isAndroid()) {
            return PlatformType.GENERIC_ANDROID;
        }

        return PlatformType.DESKTOP;
    }
}
